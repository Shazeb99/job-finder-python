import csv

# Function to display all jobs
def display_jobs():
    with open('jobs.csv', mode='r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        print("\nAvailable Jobs:")
        for row in reader:
            print(f"- {row[0]} at {row[1]} ({row[2]})")

# Function to search job by title
def search_job(title):
    with open('jobs.csv', mode='r') as file:
        reader = csv.reader(file)
        next(reader)
        found = False
        for row in reader:
            if title.lower() in row[0].lower():
                print(f"✅ Found: {row[0]} at {row[1]} ({row[2]})")
                found = True
        if not found:
            print("❌ No matching job found.")

# Function to add a new job
def add_job():
    title = input("Enter Job Title: ")
    company = input("Enter Company Name: ")
    location = input("Enter Job Location: ")
    with open('jobs.csv', mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([title, company, location])
        print("✅ Job added successfully!")

# Main menu
while True:
    print("\n=== Job Finder ===")
    print("1. View all jobs")
    print("2. Search job by title")
    print("3. Add a job")
    print("4. Exit")
    choice = input("Enter choice (1-4): ")

    if choice == '1':
        display_jobs()
    elif choice == '2':
        search_job(input("Enter job title to search: "))
    elif choice == '3':
        add_job()
    elif choice == '4':
        print("👋 Exiting... Goodbye!")
        break
    else:
        print("❗ Invalid choice. Try again.")
