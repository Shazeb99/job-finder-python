# Job Finder (Python Console App)

Hi, I'm **Shazeb** 👋 and this is my Python console project built for GirlScript Summer of Code 2025.

## 💡 What it does
This is a beginner-friendly Python project to search and manage job listings using CSV files. You can:
- View all available jobs
- Search jobs by title
- Add a new job

## ⚙️ Tech Stack
- Python
- CSV (file handling)
- Git + GitHub

## 🚀 How to Run
Make sure Python is installed, then open terminal in this folder and run:
```bash
python job_finder.py
```

## 📚 What I Learned
- Python file handling
- Functions, loops, and user input
- Creating real-world mini tools

## 🤝 Open to improvements!
Feel free to fork and contribute.
