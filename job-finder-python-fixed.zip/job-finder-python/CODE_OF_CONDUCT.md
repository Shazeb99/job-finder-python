
# Code of Conduct

We are committed to a friendly, inclusive, and harassment-free community.

- Be respectful and considerate
- Avoid demeaning or discriminatory behavior and speech
- Assume good intent

If you experience or witness unacceptable behavior, please open an issue or contact the maintainers.

This Code of Conduct is adapted from the Contributor Covenant.
