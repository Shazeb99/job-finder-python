
---
name: "🐛 Bug report"
about: Create a report to help us improve
title: "[BUG] "
labels: bug
assignees: ""
---

**Describe the bug**
A clear description of the bug.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Run '...'

**Expected behavior**

**Screenshots / Logs**

**Environment (please complete the following information):**
- OS: [e.g. Windows 10]
- Python version: [e.g. 3.11]

**Additional context**
Add any other context about the problem here.
