
import json
import os
import uuid
from typing import List, Dict, Optional

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "jobs.json")

def _load() -> List[Dict]:
    if not os.path.exists(DATA_PATH):
        return []
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def _save(jobs: List[Dict]) -> None:
    os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
    with open(DATA_PATH, "w", encoding="utf-8") as f:
        json.dump(jobs, f, ensure_ascii=False, indent=2)

def list_jobs() -> List[Dict]:
    return _load()

def add_job(title: str, company: str, location: str, salary: Optional[float], description: str = "") -> Dict:
    jobs = _load()
    # Duplicate prevention: same title + company
    for j in jobs:
        if j["title"].strip().lower() == title.strip().lower() and j["company"].strip().lower() == company.strip().lower():
            raise ValueError("Duplicate job: same title and company already exist.")
    job = {
        "id": str(uuid.uuid4()),
        "title": title.strip(),
        "company": company.strip(),
        "location": location.strip(),
        "salary": float(salary) if salary is not None else None,
        "description": description.strip(),
    }
    jobs.append(job)
    _save(jobs)
    return job

def find_by_id(job_id: str) -> Optional[Dict]:
    jobs = _load()
    for j in jobs:
        if j["id"] == job_id:
            return j
    return None

def search_by_location(q: str) -> List[Dict]:
    q = q.strip().lower()
    return [j for j in _load() if q in j.get("location", "").lower()]

def update_job(job_id: str, **fields) -> Dict:
    jobs = _load()
    for idx, j in enumerate(jobs):
        if j["id"] == job_id:
            # If title/company are updated, ensure no duplicate with other entries
            new_title = fields.get("title", j["title"]).strip()
            new_company = fields.get("company", j["company"]).strip()
            for other in jobs:
                if other["id"] != job_id and other["title"].strip().lower() == new_title.lower() and other["company"].strip().lower() == new_company.lower():
                    raise ValueError("Update would create a duplicate (same title + company).")
            j.update({
                "title": new_title,
                "company": new_company,
                "location": fields.get("location", j["location"]).strip(),
                "salary": float(fields.get("salary")) if fields.get("salary") is not None else j.get("salary"),
                "description": fields.get("description", j.get("description", "")).strip(),
            })
            jobs[idx] = j
            _save(jobs)
            return j
    raise KeyError("Job not found.")

def delete_job(job_id: str) -> None:
    jobs = _load()
    new_jobs = [j for j in jobs if j["id"] != job_id]
    if len(new_jobs) == len(jobs):
        raise KeyError("Job not found.")
    _save(new_jobs)
