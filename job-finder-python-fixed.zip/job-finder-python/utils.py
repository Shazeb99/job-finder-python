
from colorama import Fore, Style

def header(text: str):
    print(Fore.CYAN + Style.BRIGHT + f"\n=== {text} ===" + Style.RESET_ALL)

def success(text: str):
    print(Fore.GREEN + text + Style.RESET_ALL)

def warn(text: str):
    print(Fore.YELLOW + text + Style.RESET_ALL)

def error(text: str):
    print(Fore.RED + text + Style.RESET_ALL)

def ask(prompt: str) -> str:
    return input(Fore.WHITE + Style.BRIGHT + prompt + Style.RESET_ALL).strip()
