
from colorama import init
from utils import header, success, warn, error, ask
import job_store

init(autoreset=True)

def pretty(job):
    salary = job.get("salary")
    salary_str = f"₹{salary:,.2f}" if isinstance(salary, (int, float)) else "N/A"
    return (
        f"ID: {job['id']}\n"
        f"Title: {job['title']}\n"
        f"Company: {job['company']}\n"
        f"Location: {job['location']}\n"
        f"Salary: {salary_str}\n"
        f"Description: {job.get('description','')}\n"
    )

def add_job_flow():
    header("Add Job")
    title = ask("Title: ")
    company = ask("Company: ")
    location = ask("Location: ")
    salary_raw = ask("Salary (numbers only, optional): ")
    salary = float(salary_raw) if salary_raw else None
    description = ask("Description (optional): ")
    try:
        job = job_store.add_job(title, company, location, salary, description)
        success("\nSaved!\n")
        print(pretty(job))
    except ValueError as ve:
        error(str(ve))

def list_jobs_flow():
    header("All Jobs")
    jobs = job_store.list_jobs()
    if not jobs:
        warn("No jobs yet. Add one!")
        return
    for i, j in enumerate(jobs, start=1):
        print(f"\n[{i}]\n{pretty(j)}")

def search_by_location_flow():
    header("Search by Location")
    q = ask("Enter location keyword: ")
    results = job_store.search_by_location(q)
    if not results:
        warn("No matches found.")
        return
    for i, j in enumerate(results, start=1):
        print(f"\n[{i}]\n{pretty(j)}")

def update_job_flow():
    header("Update Job")
    job_id = ask("Enter Job ID: ")
    job = job_store.find_by_id(job_id)
    if not job:
        error("Job not found.")
        return
    print("\nCurrent values (press Enter to keep):")
    title = ask(f"Title [{job['title']}]: ") or job['title']
    company = ask(f"Company [{job['company']}]: ") or job['company']
    location = ask(f"Location [{job['location']}]: ") or job['location']
    salary_raw = ask(f"Salary [{job.get('salary','N/A')}]: ")
    salary = job.get('salary')
    if salary_raw.strip():
        try:
            salary = float(salary_raw)
        except ValueError:
            error("Invalid salary. Keeping previous value.")
    description = ask(f"Description [{job.get('description','')}]: ") or job.get('description','')
    try:
        updated = job_store.update_job(job_id, title=title, company=company, location=location, salary=salary, description=description)
        success("\nUpdated!\n")
        print(pretty(updated))
    except (ValueError, KeyError) as e:
        error(str(e))

def delete_job_flow():
    header("Delete Job")
    job_id = ask("Enter Job ID: ")
    try:
        job_store.delete_job(job_id)
        success("Deleted.")
    except KeyError as e:
        error(str(e))

def menu():
    while True:
        header("Job Finder CLI")
        print("1) Add job")
        print("2) List jobs")
        print("3) Search jobs by location")
        print("4) Update a job")
        print("5) Delete a job")
        print("6) Exit")
        choice = ask("Choose an option (1-6): ")
        if choice == "1":
            add_job_flow()
        elif choice == "2":
            list_jobs_flow()
        elif choice == "3":
            search_by_location_flow()
        elif choice == "4":
            update_job_flow()
        elif choice == "5":
            delete_job_flow()
        elif choice == "6":
            header("Goodbye!")
            break
        else:
            error("Invalid choice. Try again.")

if __name__ == "__main__":
    menu()
