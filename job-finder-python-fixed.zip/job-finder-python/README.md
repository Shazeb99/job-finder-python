
# Job Finder Python (CLI)

A simple, beginner-friendly command-line tool to **add**, **list**, **search**, **update**, and **delete** job entries.  
It stores data in a local JSON file and prevents **duplicate entries** (same `title` + `company`).

## ✨ Features
- Add jobs (title, company, location, salary, description)
- Prevent duplicate entries (same title + company)
- List all jobs
- Search by location (case-insensitive partial match)
- Edit/Update job details
- Delete jobs
- Clean, colored UI (uses `colorama`)

## 🚀 Quick Start
```bash
# 1) Clone (or download zip and extract) and enter the folder
cd job-finder-python

# 2) (Optional) Create virtual environment
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

# 3) Install dependency
pip install -r requirements.txt

# 4) Run
python main.py
```

> Data is stored in `data/jobs.json`. You can safely delete that file to reset the database.

## 🧭 Usage (Menu)
You’ll see a menu with options:
- `1` Add job
- `2` List jobs
- `3` Search jobs by location
- `4` Update a job
- `5` Delete a job
- `6` Exit

## 🧑‍💻 Tech Stack
- Python 3.8+
- `colorama` for colored terminal output
- JSON file storage (no database required)

## 🤝 Contributing
Please see [`CONTRIBUTING.md`](CONTRIBUTING.md) and our [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md).  
We welcome issues and PRs! Use the provided templates in `.github/`.

## 📜 License
This project is licensed under the **MIT License**. See [`LICENSE`](LICENSE).
