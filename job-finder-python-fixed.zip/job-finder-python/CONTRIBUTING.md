
# Contributing Guidelines

Thanks for your interest in contributing!

## How to contribute
1. **Fork** the repo
2. **Create a feature branch**: `git checkout -b feat/your-feature`
3. **Commit** with a clear message: `git commit -m "feat: add cool feature"`
4. **Push** to your fork: `git push origin feat/your-feature`
5. **Open a Pull Request** using our PR template

## Coding standards
- Keep code readable and commented where needed
- Prefer small, focused commits
- Test your changes locally before pushing

## Opening Issues
Use our issue templates to create **Bug Reports** or **Feature Requests**.
Provide steps to reproduce and expected behavior where relevant.
